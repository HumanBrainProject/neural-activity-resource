/* jshint: globalstrict: true */
// Ensure that all dependencies support strict mode as well.
'use strict';
