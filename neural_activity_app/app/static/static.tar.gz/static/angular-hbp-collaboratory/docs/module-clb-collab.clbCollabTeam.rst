.. _undefined.clbCollabTeam:

============================
Namespace: ``clbCollabTeam``
============================


.. contents:: Local Navigation
   :local:

Children
========

.. toctree::
   :maxdepth: 1
   
   
Description
===========

Angular client to access Collab Team REST endpoint.






