.. _module-clb-collab.clbContext:

=========================
Namespace: ``clbContext``
=========================

Member Of :doc:`module-clb-collab`

.. contents:: Local Navigation
   :local:

Children
========

.. toctree::
   :maxdepth: 1
   
   
Description
===========




.. _module-clb-collab.clbContext.get:


Function: ``get``
=================



.. js:function:: get(uuid)

    
    :param string uuid: UUID of the context
    :return Promise: Resolve to the ClbContextModel instance
    




