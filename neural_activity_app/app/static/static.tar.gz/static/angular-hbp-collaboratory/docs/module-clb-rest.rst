====================
Module: ``clb-rest``
====================


.. contents:: Local Navigation
   :local:

Children
========

.. toctree::
   :maxdepth: 1
   
   module-clb-rest.clbResultSet
   
Description
===========

``clb-rest`` module contains util for simplifying access to Rest service.






