.. _module-clb-ui-identity.clbUserCardPopoverService:

========================================
Namespace: ``clbUserCardPopoverService``
========================================

Member Of :doc:`module-clb-ui-identity`

.. contents:: Local Navigation
   :local:

Children
========

.. toctree::
   :maxdepth: 1
   
   
Description
===========

A singleton to manage clb-usercard-popover instances






