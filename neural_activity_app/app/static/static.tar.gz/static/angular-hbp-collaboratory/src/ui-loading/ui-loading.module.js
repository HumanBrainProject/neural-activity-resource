/**
 * Provides a simple loading directive.
 * @module clb-ui-loading
 */
angular.module('clb-ui-loading', []);
