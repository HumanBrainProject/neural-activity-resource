angular.module('clb-error', []);
