/**
 * Provides UI widgets around user and groups.
 * @module clb-ui-identity
 */
angular.module('clb-ui-identity', ['lodash', 'clb-identity']);
