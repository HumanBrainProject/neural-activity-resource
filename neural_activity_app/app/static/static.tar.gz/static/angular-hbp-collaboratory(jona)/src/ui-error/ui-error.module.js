/**
 * @module clb-ui-error
 */
const UI_ERROR_TEMPLATE_DIR = "/static/angular-hbp-collaboratory/src/ui-error/";

angular.module('clb-ui-error', [
  'clb-error',
  'ui.bootstrap',
]);
