/**
 * @module clb-ui-form
 * @desc
 * clb-ui-form provides directive to ease creation of forms.
 */
angular.module('clb-ui-form', []);
