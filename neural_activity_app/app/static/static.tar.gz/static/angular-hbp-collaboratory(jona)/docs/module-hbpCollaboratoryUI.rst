.. _module-hbpCollaboratoryCore.hbpCollaboratoryUI:

==============================
Module: ``hbpCollaboratoryUI``
==============================

Member Of :doc:`module-hbpCollaboratoryCore`

.. contents:: Local Navigation
   :local:

Children
========

.. toctree::
   :maxdepth: 1
   
   module-hbpCollaboratoryUI-hbpCollaboratory
   
Description
===========

Module to load the UI part of angular-hbp-collaboratory. Try to use the
sub-modules instead.





.. _module-hbpCollaboratoryUI.UUID:


Typedef: ``UUID``
=================

A string formatted as a valid UUID4



