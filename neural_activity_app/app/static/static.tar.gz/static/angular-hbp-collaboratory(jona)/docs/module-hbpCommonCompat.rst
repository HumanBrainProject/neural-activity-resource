===========================
Module: ``hbpCommonCompat``
===========================


.. contents:: Local Navigation
   :local:

Children
========

.. toctree::
   :maxdepth: 1
   
   module-hbpCollaboratoryCore
   
Description
===========

Fix some compatibility issues with previous angular-hbp-common.






