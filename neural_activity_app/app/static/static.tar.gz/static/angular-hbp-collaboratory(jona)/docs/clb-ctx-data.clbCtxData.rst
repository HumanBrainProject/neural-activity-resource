.. _undefined.clbCtxData:

=========================
Namespace: ``clbCtxData``
=========================


.. contents:: Local Navigation
   :local:

Children
========

.. toctree::
   :maxdepth: 1
   
   
Description
===========

A service to retrieve data for a given ctx. This is a convenient
way to store JSON data for a given context. Do not use it for
Sensitive data. There is no data migration functionality available, so if
the expected data format change, you are responsible to handle the old
format on the client side.






